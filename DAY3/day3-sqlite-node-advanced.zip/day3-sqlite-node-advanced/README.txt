
DAY 3 – SQLITE + NODE.JS (ADVANCED)

Steps:
1) npm install
2) node index.js
3) Test APIs in Postman

POST   /api/students
GET    /api/students
DELETE /api/students/:id
GET    /api/logs

Trigger fires on DELETE.
